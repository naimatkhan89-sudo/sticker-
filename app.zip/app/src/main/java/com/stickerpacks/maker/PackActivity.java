package com.stickerpacks.maker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;

public class PackActivity extends Activity {
    File dir;
    TextView title, status;
    GridView grid;
    List<String> items = new ArrayList<>();
    BaseAdapter adapter;
    int cell;

    @Override protected void onCreate(Bundle sb) {
        super.onCreate(sb);
        dir = new File(Store.root(this), getIntent().getStringExtra("id"));
        cell = (getResources().getDisplayMetrics().widthPixels - Store.dp(this, 32)) / 4;
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        l.setPadding(Store.dp(this, 16), Store.dp(this, 32), Store.dp(this, 16), Store.dp(this, 8));
        title = new TextView(this);
        title.setTextSize(22);
        title.setTextColor(Color.BLACK);
        Button add = Store.btn(this, "سٹیکر شامل کریں (گیلری سے کئی ایک ساتھ)", true);
        Button wa = Store.btn(this, "واٹس ایپ میں ایڈ کریں", true);
        LinearLayout row = new LinearLayout(this);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button ren = Store.btn(this, "نام بدلیں", false), sh = Store.btn(this, "شیئر", false), rm = Store.btn(this, "پیک حذف", false);
        row.addView(ren, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(sh, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(rm, new LinearLayout.LayoutParams(0, -2, 1));
        status = new TextView(this);
        grid = new GridView(this);
        grid.setNumColumns(4);
        adapter = new BaseAdapter() {
            public int getCount() { return items.size() < 30 ? items.size() + 1 : items.size(); }
            public Object getItem(int i) { return i; }
            public long getItemId(int i) { return i; }
            public View getView(int i, View cv, ViewGroup p) {
                ImageView iv = new ImageView(PackActivity.this);
                iv.setLayoutParams(new AbsListView.LayoutParams(cell, cell));
                iv.setPadding(6, 6, 6, 6);
                iv.setBackgroundColor(0xFFEEEEEE);
                if (i == items.size()) iv.setImageResource(android.R.drawable.ic_input_add);
                else iv.setImageBitmap(Store.thumb(new File(dir, items.get(i)), 4));
                return iv;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, i, id) -> {
            if (i == items.size()) pick(); else options(items.get(i));
        });
        l.addView(title); l.addView(add); l.addView(wa); l.addView(row); l.addView(status);
        l.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(l);
        add.setOnClickListener(v -> pick());
        wa.setOnClickListener(v -> toWhatsApp());
        ren.setOnClickListener(v -> {
            String[] i = Store.info(dir);
            Store.form(this, "نام بدلیں", i[0], i[1], (n, a) -> {
                Store.writeInfo(dir, n, a, Integer.parseInt(i[2]) + 1);
                refresh();
            });
        });
        sh.setOnClickListener(v -> share());
        rm.setOnClickListener(v -> new AlertDialog.Builder(this).setMessage("پورا پیک حذف کریں؟")
            .setPositiveButton("حذف", (d, w) -> { Store.del(dir); finish(); })
            .setNegativeButton("منسوخ", null).show());
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    void refresh() {
        String[] i = Store.info(dir);
        if (i == null) { finish(); return; }
        items = Store.stickers(dir);
        title.setText(i[0] + "  (" + items.size() + "/30)");
        adapter.notifyDataSetChanged();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    void pick() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(Intent.createChooser(i, "تصویریں"), 100);
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq != 100 || rs != RESULT_OK || d == null) return;
        final List<Uri> uris = new ArrayList<>();
        if (d.getClipData() != null) {
            for (int i = 0; i < d.getClipData().getItemCount(); i++) uris.add(d.getClipData().getItemAt(i).getUri());
        } else if (d.getData() != null) uris.add(d.getData());
        addImages(uris);
    }

    void addImages(final List<Uri> uris) {
        status.setText("تیار ہو رہا ہے...");
        new Thread(() -> {
            File cur = dir;
            String[] inf = Store.info(dir);
            int made = 0, added = 0;
            for (Uri u : uris) {
                Bitmap s = Store.square(this, u);
                if (s == null) continue;
                if (Store.stickers(cur).size() >= 30) {
                    cur = Store.newPack(this, inf[0] + " " + (made + 2), inf[1]);
                    made++;
                }
                if (Store.add(cur, s)) added++;
                s.recycle();
                final int a = added;
                runOnUiThread(() -> status.setText(a + "/" + uris.size()));
            }
            final int mk = made, ad = added;
            runOnUiThread(() -> {
                refresh();
                status.setText(ad + " سٹیکر شامل ہوئے" + (mk > 0 ? "، " + mk + " نیا پیک بھی بنا (30 کی حد)" : ""));
            });
        }).start();
    }

    void options(final String f) {
        new AlertDialog.Builder(this).setItems(new String[]{"پیک کا آئیکن بنائیں", "سٹیکر حذف کریں"}, (dg, w) -> {
            if (w == 0) {
                try {
                    Store.writeTray(dir, BitmapFactory.decodeFile(new File(dir, f).getPath()));
                    Store.bump(dir);
                    toast("آئیکن بدل گیا");
                } catch (Exception e) { toast("آئیکن نہیں بدلا"); }
            } else {
                new File(dir, f).delete();
                Store.bump(dir);
                refresh();
            }
        }).show();
    }

    void toWhatsApp() {
        if (items.size() < 3) { toast("واٹس ایپ کے لیے کم از کم 3 سٹیکر ضروری ہیں"); return; }
        String[] i = Store.info(dir);
        Intent it = new Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK");
        it.putExtra("sticker_pack_id", dir.getName());
        it.putExtra("sticker_pack_authority", Store.AUTH);
        it.putExtra("sticker_pack_name", i[0]);
        try { startActivityForResult(it, 200); }
        catch (ActivityNotFoundException e) { toast("واٹس ایپ نہیں ملا"); }
    }

    void share() {
        Uri u = Uri.parse("content://" + Store.AUTH + "/share/" + dir.getName() + "/" + dir.getName() + ".wastickers");
        Intent s = new Intent(Intent.ACTION_SEND);
        s.setType("application/octet-stream");
        s.putExtra(Intent.EXTRA_STREAM, u);
        s.setClipData(ClipData.newRawUri("", u));
        s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(s, "شیئر"));
    }
}
