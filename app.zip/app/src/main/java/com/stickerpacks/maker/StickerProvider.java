package com.stickerpacks.maker;

import android.content.*;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.*;

public class StickerProvider extends ContentProvider {
    static final String AUTH = Store.AUTH;
    static final String[] PACK_COLS = {"sticker_pack_identifier", "sticker_pack_name", "sticker_pack_publisher",
        "sticker_pack_icon", "android_play_store_link", "ios_app_download_link", "sticker_pack_publisher_email",
        "sticker_pack_publisher_website", "sticker_pack_privacy_policy_website",
        "sticker_pack_license_agreement_website", "image_data_version", "whatsapp_will_not_cache_stickers",
        "animated_sticker_pack"};
    UriMatcher m = new UriMatcher(UriMatcher.NO_MATCH);
    File root;

    @Override public boolean onCreate() {
        root = Store.root(getContext());
        m.addURI(AUTH, "metadata", 1);
        m.addURI(AUTH, "metadata/*", 2);
        m.addURI(AUTH, "stickers/*", 3);
        m.addURI(AUTH, "stickers_asset/*/*", 4);
        m.addURI(AUTH, "share/*/*", 5);
        return true;
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) {
        int c = m.match(u);
        if (c == 1 || c == 2) {
            MatrixCursor mc = new MatrixCursor(PACK_COLS);
            File[] ds = c == 1 ? root.listFiles() : new File[]{new File(root, u.getLastPathSegment())};
            if (ds != null) for (File d : ds) {
                String[] i = Store.info(d);
                if (i == null || Store.stickers(d).size() < 1) continue;
                mc.addRow(new Object[]{d.getName(), i[0], i[1], "tray.png", "", "", "", "", "", "", i[2], 0, 0});
            }
            return mc;
        }
        if (c == 3) {
            MatrixCursor mc = new MatrixCursor(new String[]{"sticker_file_name", "sticker_emoji", "sticker_accessibility_text"});
            for (String f : Store.stickers(new File(root, u.getLastPathSegment())))
                mc.addRow(new Object[]{f, "\uD83D\uDE00", ""});
            return mc;
        }
        if (c == 5) {
            MatrixCursor mc = new MatrixCursor(new String[]{"_display_name", "_size"});
            try {
                File z = Store.zip(getContext(), new File(root, new File(u.getPathSegments().get(1)).getName()));
                mc.addRow(new Object[]{u.getLastPathSegment(), z.length()});
            } catch (IOException e) { }
            return mc;
        }
        return null;
    }

    @Override public AssetFileDescriptor openAssetFile(Uri u, String mode) throws FileNotFoundException {
        if (m.match(u) != 4) throw new FileNotFoundException();
        java.util.List<String> s = u.getPathSegments();
        File f = new File(new File(root, new File(s.get(1)).getName()), new File(s.get(2)).getName());
        return new AssetFileDescriptor(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY), 0, AssetFileDescriptor.UNKNOWN_LENGTH);
    }

    @Override public ParcelFileDescriptor openFile(Uri u, String mode) throws FileNotFoundException {
        if (m.match(u) != 5) throw new FileNotFoundException();
        try {
            File z = Store.zip(getContext(), new File(root, new File(u.getPathSegments().get(1)).getName()));
            return ParcelFileDescriptor.open(z, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (IOException e) { throw new FileNotFoundException(); }
    }

    @Override public String getType(Uri u) {
        switch (m.match(u)) {
            case 1: return "vnd.android.cursor.dir/vnd." + AUTH + ".metadata";
            case 2: return "vnd.android.cursor.item/vnd." + AUTH + ".metadata";
            case 3: return "vnd.android.cursor.dir/vnd." + AUTH + ".stickers";
            case 4: return u.getLastPathSegment().endsWith(".png") ? "image/png" : "image/webp";
            case 5: return "application/octet-stream";
        }
        return null;
    }

    @Override public Uri insert(Uri u, ContentValues v) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri u, String s, String[] a) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { throw new UnsupportedOperationException(); }
}
