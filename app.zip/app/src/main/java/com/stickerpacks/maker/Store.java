package com.stickerpacks.maker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.*;
import android.net.Uri;
import android.os.Build;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

final class Store {
    static final String AUTH = "com.stickerpacks.maker.stickercontentprovider";
    static int seq = 0;

    interface Callback { void run(String name, String author); }

    static int dp(Context c, int v) { return (int) (v * c.getResources().getDisplayMetrics().density); }

    static Button btn(Context c, String t, boolean primary) {
        Button b = new Button(c);
        b.setText(t);
        b.setAllCaps(false);
        if (primary) { b.setBackgroundColor(0xFF128C4A); b.setTextColor(Color.WHITE); }
        return b;
    }

    static File root(Context c) { File r = new File(c.getFilesDir(), "packs"); r.mkdirs(); return r; }

    static String[] info(File d) {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(new File(d, "info.txt")), StandardCharsets.UTF_8));
            String n = r.readLine(), a = r.readLine(), v = r.readLine();
            r.close();
            if (n == null) return null;
            return new String[]{n, a == null ? "" : a, v == null ? "1" : v};
        } catch (Exception e) { return null; }
    }

    static void writeInfo(File d, String n, String a, int v) {
        try {
            FileOutputStream f = new FileOutputStream(new File(d, "info.txt"));
            f.write((n.replace("\n", " ") + "\n" + a.replace("\n", " ") + "\n" + v).getBytes(StandardCharsets.UTF_8));
            f.close();
        } catch (IOException e) { }
    }

    static void bump(File d) {
        String[] i = info(d);
        if (i != null) writeInfo(d, i[0], i[1], Integer.parseInt(i[2]) + 1);
    }

    static List<String> stickers(File d) {
        List<String> r = new ArrayList<>();
        String[] a = d.list();
        if (a != null) for (String s : a) if (s.endsWith(".webp")) r.add(s);
        Collections.sort(r);
        return r;
    }

    static File newPack(Context c, String n, String a) {
        File d = new File(root(c), "p" + System.currentTimeMillis() + "_" + (seq++ % 1000));
        d.mkdirs();
        writeInfo(d, n, a, 1);
        return d;
    }

    static String nextName() {
        return String.format(Locale.US, "s%013d%03d.webp", System.currentTimeMillis(), seq++ % 1000);
    }

    static void del(File d) {
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        d.delete();
    }

    static void writeTray(File d, Bitmap s) throws IOException {
        FileOutputStream fo = new FileOutputStream(new File(d, "tray.png"));
        Bitmap.createScaledBitmap(s, 96, 96, true).compress(Bitmap.CompressFormat.PNG, 100, fo);
        fo.close();
    }

    static void writeWebp(Bitmap b, File f) throws IOException {
        Bitmap.CompressFormat fm = Build.VERSION.SDK_INT >= 30 ? Bitmap.CompressFormat.WEBP_LOSSY : Bitmap.CompressFormat.WEBP;
        int q = 90;
        ByteArrayOutputStream bo;
        do {
            bo = new ByteArrayOutputStream();
            b.compress(fm, q, bo);
            q -= 15;
        } while (bo.size() > 100000 && q > 10);
        FileOutputStream fo = new FileOutputStream(f);
        fo.write(bo.toByteArray());
        fo.close();
    }

    static boolean add(File d, Bitmap s) {
        try {
            writeWebp(s, new File(d, nextName()));
            if (!new File(d, "tray.png").exists()) writeTray(d, s);
            bump(d);
            return true;
        } catch (IOException e) { return false; }
    }

    static Bitmap square(Context c, Uri u) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = c.getContentResolver().openInputStream(u);
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int ss = 1;
            while (o.outWidth / ss > 1024 || o.outHeight / ss > 1024) ss *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = ss;
            in = c.getContentResolver().openInputStream(u);
            Bitmap b = BitmapFactory.decodeStream(in, null, o);
            in.close();
            if (b == null) return null;
            Bitmap r = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888);
            float sc = Math.min(512f / b.getWidth(), 512f / b.getHeight());
            float w = b.getWidth() * sc, h = b.getHeight() * sc;
            new Canvas(r).drawBitmap(b, null, new RectF((512 - w) / 2, (512 - h) / 2, (512 + w) / 2, (512 + h) / 2), new Paint(Paint.FILTER_BITMAP_FLAG));
            b.recycle();
            return r;
        } catch (Exception e) { return null; }
    }

    static Bitmap thumb(File f, int sample) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inSampleSize = sample;
        return BitmapFactory.decodeFile(f.getPath(), o);
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        return bo.toByteArray();
    }

    static void put(ZipOutputStream o, String n, byte[] b) throws IOException {
        o.putNextEntry(new ZipEntry(n));
        o.write(b);
        o.closeEntry();
    }

    static File zip(Context c, File d) throws IOException {
        File z = new File(c.getCacheDir(), d.getName() + ".wastickers");
        ZipOutputStream o = new ZipOutputStream(new FileOutputStream(z));
        String[] i = info(d);
        put(o, "title.txt", i[0].getBytes(StandardCharsets.UTF_8));
        put(o, "author.txt", i[1].getBytes(StandardCharsets.UTF_8));
        File t = new File(d, "tray.png");
        if (t.exists()) put(o, "tray.png", readAll(new FileInputStream(t)));
        for (String s : stickers(d)) put(o, s, readAll(new FileInputStream(new File(d, s))));
        o.close();
        return z;
    }

    static int importZip(Context c, Uri u) {
        try {
            ZipInputStream z = new ZipInputStream(c.getContentResolver().openInputStream(u));
            String t = "Imported", a = "";
            TreeMap<String, byte[]> st = new TreeMap<>((x, y) -> x.length() != y.length() ? x.length() - y.length() : x.compareTo(y));
            byte[] tray = null;
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String n = new File(e.getName()).getName();
                byte[] b = readAll(z);
                if (n.equals("title.txt")) t = new String(b, StandardCharsets.UTF_8).trim();
                else if (n.equals("author.txt")) a = new String(b, StandardCharsets.UTF_8).trim();
                else if (n.endsWith(".webp")) st.put(n, b);
                else if (n.endsWith(".png")) tray = b;
            }
            z.close();
            if (st.isEmpty()) return 0;
            File d = newPack(c, t, a);
            int k = 0;
            for (byte[] b : st.values()) {
                if (k >= 30) break;
                FileOutputStream f = new FileOutputStream(new File(d, nextName()));
                f.write(b);
                f.close();
                k++;
            }
            Bitmap tb = tray != null ? BitmapFactory.decodeByteArray(tray, 0, tray.length) : null;
            if (tb == null) tb = BitmapFactory.decodeFile(new File(d, stickers(d).get(0)).getPath());
            writeTray(d, tb);
            return k;
        } catch (Exception ex) { return 0; }
    }

    static void form(Activity a, String title, String n, String au, Callback cb) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        l.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0);
        final EditText e1 = new EditText(a), e2 = new EditText(a);
        e1.setHint("پیک کا نام"); e1.setText(n);
        e2.setHint("مصنف کا نام"); e2.setText(au);
        l.addView(e1);
        l.addView(e2);
        new AlertDialog.Builder(a).setTitle(title).setView(l)
            .setPositiveButton("ٹھیک ہے", (d, w) -> {
                String x = e1.getText().toString().trim();
                cb.run(x.isEmpty() ? "My Stickers" : x, e2.getText().toString().trim());
            }).setNegativeButton("منسوخ", null).show();
    }
}
