package com.stickerpacks.maker;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText name, author;
    TextView cnt;
    Button create;
    LinearLayout list;
    List<Uri> picked = new ArrayList<>();
    File root;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    Button btn(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        return b;
    }

    @Override protected void onCreate(Bundle sb) {
        super.onCreate(sb);
        root = new File(getFilesDir(), "packs");
        root.mkdirs();
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        l.setPadding(dp(16), dp(32), dp(16), dp(16));
        sv.addView(l);
        TextView h = new TextView(this);
        h.setText("سٹیکر پیک میکر");
        h.setTextSize(24);
        l.addView(h);
        name = new EditText(this); name.setHint("پیک کا نام"); name.setText("My Stickers");
        author = new EditText(this); author.setHint("مصنف کا نام"); author.setText("Me");
        l.addView(name); l.addView(author);
        Button pick = btn("تصویریں چنیں (100 تک)");
        cnt = new TextView(this);
        create = btn("پیک بنائیں");
        l.addView(pick); l.addView(cnt); l.addView(create);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        l.addView(list);
        setContentView(sv);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(Intent.createChooser(i, "تصویریں"), 100);
        });
        create.setOnClickListener(v -> build());
        refresh();
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq != 100 || rs != RESULT_OK || d == null) return;
        picked.clear();
        if (d.getClipData() != null) {
            for (int i = 0; i < d.getClipData().getItemCount() && i < 100; i++)
                picked.add(d.getClipData().getItemAt(i).getUri());
        } else if (d.getData() != null) picked.add(d.getData());
        cnt.setText(picked.size() + " تصویریں چنی گئیں");
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    void build() {
        if (picked.size() < 3) { toast("کم از کم 3 تصویریں چنیں"); return; }
        final String t = name.getText().toString().trim(), a = author.getText().toString().trim();
        final List<Uri> uris = new ArrayList<>(picked);
        create.setEnabled(false);
        new Thread(() -> {
            int n = uris.size(), packs = (n + 29) / 30, per = (n + packs - 1) / packs;
            long ts = System.currentTimeMillis();
            for (int pi = 0; pi < packs; pi++) {
                File d = new File(root, "p" + ts + "_" + pi);
                d.mkdirs();
                int k = 0;
                for (int i = pi * per; i < Math.min(n, (pi + 1) * per); i++) {
                    Bitmap s = square(uris.get(i));
                    if (s == null) continue;
                    k++;
                    try {
                        webp(s, new File(d, k + ".webp"));
                        if (k == 1) {
                            FileOutputStream fo = new FileOutputStream(new File(d, "tray.png"));
                            Bitmap.createScaledBitmap(s, 96, 96, true).compress(Bitmap.CompressFormat.PNG, 100, fo);
                            fo.close();
                        }
                    } catch (IOException e) { k--; }
                    s.recycle();
                    final int done = pi * per + k;
                    runOnUiThread(() -> cnt.setText("تیار ہو رہا ہے... " + done + "/" + n));
                }
                if (k < 3) { del(d); continue; }
                try {
                    FileWriter w = new FileWriter(new File(d, "info.txt"));
                    w.write((packs > 1 ? t + " " + (pi + 1) : t) + "\n" + a);
                    w.close();
                } catch (IOException e) { del(d); }
            }
            runOnUiThread(() -> {
                picked.clear();
                cnt.setText("پیک تیار ہیں");
                create.setEnabled(true);
                refresh();
            });
        }).start();
    }

    Bitmap square(Uri u) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(u);
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int ss = 1;
            while (o.outWidth / ss > 1024 || o.outHeight / ss > 1024) ss *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = ss;
            in = getContentResolver().openInputStream(u);
            Bitmap b = BitmapFactory.decodeStream(in, null, o);
            in.close();
            if (b == null) return null;
            Bitmap r = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888);
            float sc = Math.min(512f / b.getWidth(), 512f / b.getHeight());
            float w = b.getWidth() * sc, h = b.getHeight() * sc;
            new Canvas(r).drawBitmap(b, null, new RectF((512 - w) / 2, (512 - h) / 2, (512 + w) / 2, (512 + h) / 2), new Paint(Paint.FILTER_BITMAP_FLAG));
            b.recycle();
            return r;
        } catch (Exception e) { return null; }
    }

    void webp(Bitmap b, File f) throws IOException {
        Bitmap.CompressFormat fm = Build.VERSION.SDK_INT >= 30 ? Bitmap.CompressFormat.WEBP_LOSSY : Bitmap.CompressFormat.WEBP;
        int q = 90;
        ByteArrayOutputStream bo;
        do {
            bo = new ByteArrayOutputStream();
            b.compress(fm, q, bo);
            q -= 15;
        } while (bo.size() > 100000 && q > 10);
        FileOutputStream fo = new FileOutputStream(f);
        fo.write(bo.toByteArray());
        fo.close();
    }

    void del(File d) {
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        d.delete();
    }

    void refresh() {
        list.removeAllViews();
        File[] ds = root.listFiles();
        if (ds == null) return;
        Arrays.sort(ds);
        for (File d : ds) {
            String[] i = StickerProvider.info(d);
            if (i == null) continue;
            TextView tv = new TextView(this);
            tv.setText(i[0] + " (" + StickerProvider.stickers(d).size() + " سٹیکر)");
            tv.setTextSize(18);
            tv.setPadding(0, dp(16), 0, 0);
            Button add = btn("واٹس ایپ میں ایڈ کریں"), rm = btn("حذف کریں");
            add.setOnClickListener(v -> {
                Intent it = new Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK");
                it.putExtra("sticker_pack_id", d.getName());
                it.putExtra("sticker_pack_authority", StickerProvider.AUTH);
                it.putExtra("sticker_pack_name", i[0]);
                try { startActivityForResult(it, 200); }
                catch (ActivityNotFoundException e) { toast("واٹس ایپ نہیں ملا"); }
            });
            rm.setOnClickListener(v -> { del(d); refresh(); });
            list.addView(tv); list.addView(add); list.addView(rm);
        }
    }
}
