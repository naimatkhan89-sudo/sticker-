package com.stickerpacks.maker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;

public class MainActivity extends Activity {
    List<File> packs = new ArrayList<>();
    BaseAdapter adapter;
    TextView status;

    @Override protected void onCreate(Bundle sb) {
        super.onCreate(sb);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        l.setPadding(Store.dp(this, 16), Store.dp(this, 32), Store.dp(this, 16), Store.dp(this, 8));
        TextView h = new TextView(this);
        h.setText("میرے سٹیکر پیک");
        h.setTextSize(24);
        h.setTextColor(Color.BLACK);
        LinearLayout row = new LinearLayout(this);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button nw = Store.btn(this, "+ نیا پیک", true), im = Store.btn(this, "امپورٹ", false);
        row.addView(nw, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(im, new LinearLayout.LayoutParams(0, -2, 1));
        status = new TextView(this);
        ListView lv = new ListView(this);
        adapter = new BaseAdapter() {
            public int getCount() { return packs.size(); }
            public Object getItem(int i) { return packs.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View cv, ViewGroup p) {
                File d = packs.get(i);
                String[] inf = Store.info(d);
                LinearLayout r = new LinearLayout(MainActivity.this);
                r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(0, Store.dp(MainActivity.this, 8), 0, Store.dp(MainActivity.this, 8));
                ImageView iv = new ImageView(MainActivity.this);
                iv.setLayoutParams(new LinearLayout.LayoutParams(Store.dp(MainActivity.this, 64), Store.dp(MainActivity.this, 64)));
                Bitmap b = BitmapFactory.decodeFile(new File(d, "tray.png").getPath());
                if (b != null) iv.setImageBitmap(b);
                LinearLayout t = new LinearLayout(MainActivity.this);
                t.setOrientation(LinearLayout.VERTICAL);
                t.setPadding(Store.dp(MainActivity.this, 12), 0, Store.dp(MainActivity.this, 12), 0);
                TextView n = new TextView(MainActivity.this), s = new TextView(MainActivity.this);
                n.setText(inf[0]); n.setTextSize(18); n.setTextColor(Color.BLACK);
                s.setText(Store.stickers(d).size() + "/30 سٹیکر  •  " + inf[1]);
                t.addView(n); t.addView(s);
                r.addView(iv); r.addView(t);
                return r;
            }
        };
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((p, v, i, id) -> open(packs.get(i)));
        l.addView(h); l.addView(row); l.addView(status);
        l.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(l);
        nw.setOnClickListener(v -> Store.form(this, "نیا پیک", "", "", (n, a) -> open(Store.newPack(this, n, a))));
        im.setOnClickListener(v -> {
            Intent it = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            it.setType("*/*");
            it.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(it, 5);
        });
    }

    void open(File d) {
        Intent i = new Intent(this, PackActivity.class);
        i.putExtra("id", d.getName());
        startActivity(i);
    }

    @Override protected void onResume() {
        super.onResume();
        packs.clear();
        File[] ds = Store.root(this).listFiles();
        if (ds != null) {
            Arrays.sort(ds);
            for (File d : ds) if (Store.info(d) != null) packs.add(d);
        }
        status.setText(packs.isEmpty() ? "ابھی کوئی پیک نہیں۔ \"+ نیا پیک\" دبائیں۔" : "");
        adapter.notifyDataSetChanged();
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq != 5 || rs != RESULT_OK || d == null || d.getData() == null) return;
        final Uri u = d.getData();
        status.setText("امپورٹ ہو رہا ہے...");
        new Thread(() -> {
            int k = Store.importZip(this, u);
            runOnUiThread(() -> {
                status.setText(k > 0 ? k + " سٹیکر امپورٹ ہوئے" : "امپورٹ نہیں ہو سکا");
                onResume();
            });
        }).start();
    }
}
